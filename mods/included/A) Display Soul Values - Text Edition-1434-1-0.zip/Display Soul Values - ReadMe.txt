Display Soul Values
Version 1.0
By Dziggy

Displays the number of souls you will receive from soul-giving items. The number will be displayed in parentheses after the item's name in the menu.


INSTALLATION:

* Simply place the "msg" folder into the game's installation directory, overwriting the game's original file. I advise you to make a backup of the original file first in case you want to uninstall the mod later.


MOD CREDITS:

* Dziggy - Creator


MOD PERMISSIONS:

* All the assets in this file belong to the author, or are from free-to-use modder's resources
* You are not allowed to upload this file to other sites under any circumstances
* You must get permission from me before you are allowed to modify my files to improve it
* You can convert this file to work with other games as long as you credit me as the creator of the file
* You are allowed to use the assets in this file without permission as long as you credit me
* You are not allowed to use assets from this file in any mods/files that are being sold, for money, on Steam Workshop or other platforms
* You must get permission to earn Donation Points for your mods if they use my assets 


DOWNLOAD SOURCE AND SUPPORT:

http://www.nexusmods.com/darksouls/mods/1434/

